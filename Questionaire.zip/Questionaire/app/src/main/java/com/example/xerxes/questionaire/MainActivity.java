package com.example.xerxes.questionaire;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    int scoreCount = 0; /* initialise score count to zero */
    String strN;    /* initialise string for submit button toast */
    String strA;    /* initialise string for answer button toast */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* method called when submit button is clicked */
    public void complete(View view) {
        q1Radio();
        q2Radio();
        q3Radio();
        q4Radio();
        q5Radio();
        q6Box();
        strN = "Name : " + NameEdit() + "\n";
        strN += "Exam No : " + Exam() + "\n";
        strN += "Date : " + Date() + "\n";
        strN += "Total Score = " + String.valueOf(scoreCount + 2) + "\n";
        if (scoreCount < 20){
            strN += "Fail \n";
        }
        if (scoreCount <= 45){
            strN += "Pass \n";
        }
        if (scoreCount > 45){
            strN += "Excellent";
        }

        Toast.makeText(MainActivity.this, strN, Toast.LENGTH_LONG).show();
        submitButton();
    }

    /* method called when showAnswer button is clicked */
    public void showAnswer (View view) {
        flashAnswer();
    }

    /* method called when reset button is clicked */
    public void Reset (View view) {
        resetFin();
    }


    /* get User name text*/
    private String NameEdit() {
        EditText name = (findViewById(R.id.name));
        String StrNam = name.getText().toString();
        return StrNam;
    }

    /* get exam number text*/
    private String Exam() {
        EditText name = (findViewById(R.id.exam));
        String StrNam = name.getText().toString();
        return StrNam;
    }

    /* get date text*/
    private String Date() {
        EditText name = (findViewById(R.id.date));
        String StrNam = name.getText().toString();
        return StrNam;
    }


    /* score user if the right radio button is clicked*/
    private void q1Radio() {
        RadioGroup rdGroup = findViewById(R.id.radGrp1);
        int selectedId = rdGroup.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton = findViewById(selectedId);
        RadioButton radButton = findViewById(R.id.radGrp1a2);

        if (StrButton.equals(radButton)) {
            scoreCount = scoreCount + 10;
        }
    }

    /* score user if the right check Box is clicked*/
    private void q2Radio() {
        CheckBox box1 = findViewById(R.id.chkBx2a1);
        CheckBox box2 = findViewById(R.id.chkBx2a2);
        CheckBox box4 = findViewById(R.id.chkBx2a4);
        if (box1.isChecked()) {
            scoreCount = scoreCount + 3;
        }
        if (box2.isChecked()) {
            scoreCount = scoreCount + 3;
        }
        if (box4.isChecked()) {
            scoreCount = scoreCount + 3;
        }
    }

    /* score user if the right radio button is clicked*/
    private void q3Radio() {
        RadioGroup rdGroup = findViewById(R.id.radGrp2);
        int selectedId = rdGroup.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton = findViewById(selectedId);
        RadioButton radButton = findViewById(R.id.radGrp2a4);

        if (StrButton.equals(radButton)) {
            scoreCount = scoreCount + 10;
        }
    }

    /* score user if the right radio button is clicked*/
    private void q4Radio() {
        RadioGroup rdGroup = findViewById(R.id.radGrp3);
        int selectedId = rdGroup.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton = findViewById(selectedId);
        RadioButton radButton = findViewById(R.id.radGrp3a1);

        if (StrButton.equals(radButton)) {
            scoreCount = scoreCount + 10;
        }
    }

    /* score user if the right radio button is clicked*/
    private void q5Radio() {
        RadioGroup rdGroup = findViewById(R.id.radGrp5);
        int selectedId = rdGroup.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton = findViewById(selectedId);
        RadioButton radButton = findViewById(R.id.radGrp5a2);

        if (StrButton.equals(radButton)) {
            scoreCount = scoreCount + 10;
        }
    }

    /* set text box limit and scoe user if the right words are present in the string*/
    private void q6Box() {

        CheckBox box2 = findViewById(R.id.chkBx6a2);
        CheckBox box3 = findViewById(R.id.chkBx6a3);
        CheckBox box4 = findViewById(R.id.chkBx6a4);
        if (box2.isChecked()) {
            scoreCount = scoreCount + 3;
        }
        if (box3.isChecked()) {
            scoreCount = scoreCount + 3;
        }
        if (box4.isChecked()) {
            scoreCount = scoreCount + 3;
        }
    }



    /* hides submit button when it is clicked and ends the exam*/
    private void submitButton (){
        Button fButton = findViewById(R.id.submit);
         fButton.setVisibility(View.GONE);
    }

    /* called by show Answer displays answers to all the questions in a shot while*/
    private void flashAnswer (){
        Button fButton = findViewById(R.id.answer);
        RadioButton radButton = findViewById(R.id.radGrp1a2);
        String answer1 = (String) radButton.getText();
        CheckBox box1 = findViewById(R.id.chkBx2a1);
        String ansBox1 = (String) box1.getText();
        CheckBox box2 = findViewById(R.id.chkBx2a2);
        String ansBox2 = (String) box2.getText();
        CheckBox box4 = findViewById(R.id.chkBx2a4);
        String ansBox4 = (String) box4.getText();
        RadioButton radButton1 = findViewById(R.id.radGrp2a4);
        String answer2 = (String) radButton1.getText();
        RadioButton radButton2 = findViewById(R.id.radGrp3a1);
        String answer3 = (String) radButton2.getText();
        RadioButton radButton3 = findViewById(R.id.radGrp5a2);
        String answer4 = (String) radButton3.getText();
        CheckBox box5 = findViewById(R.id.chkBx6a2);
        String ansBox5 = (String) box5.getText();
        CheckBox box6 = findViewById(R.id.chkBx6a3);
        String ansBox6 = (String) box6.getText();
        CheckBox box7 = findViewById(R.id.chkBx6a4);
        String ansBox7 = (String) box7.getText();
        strA = "Question 1: " + answer1 + "\n";
        strA += "Question 2 \na: " + ansBox1 + "\n";
        strA += "b: " + ansBox2 + "\n";
        strA += "c: " + ansBox4 + "\n";
        strA += "Question 3: " + answer2 + "\n";
        strA += "Question 4: " + answer3 + "\n";
        strA += "Question 5: " + answer4 + "\n";
        strA += "Question 6 \nb: " + ansBox5 + "\n";
        strA += "b: " + ansBox6 + "\n";
        strA += "c: " + ansBox7 + "\n";

        Toast.makeText(MainActivity.this, strA, Toast.LENGTH_SHORT).show();
    }

    /* called by reset clears all checked boxes, radio buttons and returns the page to default view*/
    private void resetFin () {
        Button fButton = findViewById(R.id.reset);

        EditText name = (findViewById(R.id.name));
            name.getText().clear();

        EditText ex = (findViewById(R.id.exam));
        ex.getText().clear();

        EditText dat = (findViewById(R.id.date));
        dat.getText().clear();


        RadioGroup rdGroup = findViewById(R.id.radGrp1);
        int selectedId = rdGroup.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton = findViewById(selectedId);
        StrButton.setChecked(false);

        CheckBox box1 = findViewById(R.id.chkBx2a1);
        box1.setChecked(false);
        CheckBox box2 = findViewById(R.id.chkBx2a2);
        box2.setChecked(false);
        CheckBox box3 = findViewById(R.id.chkBx2a3);
        box3.setChecked(false);
        CheckBox box4 = findViewById(R.id.chkBx2a4);
        box4.setChecked(false);

        RadioGroup rdGroup1 = findViewById(R.id.radGrp2);
        int selectedId1 = rdGroup1.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton1 = findViewById(selectedId1);
        StrButton1.setChecked(false);

        RadioGroup rdGroup2 = findViewById(R.id.radGrp3);
        int selectedId2 = rdGroup2.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton2 = findViewById(selectedId2);
        StrButton2.setChecked(false);

        RadioGroup rdGroup3 = findViewById(R.id.radGrp5);
        int selectedId3 = rdGroup3.getCheckedRadioButtonId(); /* get selected radio button Id in the group*/
        RadioButton StrButton3 = findViewById(selectedId3);
        StrButton3.setChecked(false);

        CheckBox box5 = findViewById(R.id.chkBx6a1);
        box5.setChecked(false);
        CheckBox box6 = findViewById(R.id.chkBx6a2);
        box6.setChecked(false);
        CheckBox box7 = findViewById(R.id.chkBx6a3);
        box7.setChecked(false);
        CheckBox box8 = findViewById(R.id.chkBx6a4);
        box8.setChecked(false);

        Button subBut = findViewById(R.id.submit);
            subBut.setVisibility(View.VISIBLE);


    }

}




